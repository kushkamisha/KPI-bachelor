/**
 * Java labs- Lab1
 * @version 1.0 2018-02-09
 * @author Misha Kushka
*/
import java.util.Scanner;

class Expression {       
    	double result;
    	double i, j;
    	int n, m;
    	final int C;
    	
    	Expression(int _C, int _n, int _m) {
    		n = _n;
    		m = _m;
    		C = _C;
    		result = 0;
    	}
    	
    	double calcExpression() {
    		double first, second;
    		for (float i = 0; i <= n; i++) {
    			for (float j = 0; j <= m; j++) {
    				first = i / (float)j;
    				second = i + C;
    				result += first / second;
    				if (Double.isNaN(result)) {
    					System.out.println("NaN - try another start number.");
    					System.exit(0);
    				}
    			}
    		}
    		
    		return result;
    	}
}

public class First {
    public static void main(String[] args) {
        final int C = 2;
        int n = -1, m = -1;
        
        // Enter n and m
        Scanner scanner = new Scanner(System.in);
        
        // Read n
        while (true) {
	        System.out.print("Enter n: ");
	        
	        try {
	        		n = Integer.parseInt(scanner.nextLine());
	        		if (n < 0) {
	        			System.out.println("n must be positive");
	        		}
	        } catch (NumberFormatException e) {
	        		System.out.println("n must be an int number");
	        }
	        
	        if (n >= 0) {
	        		break;
	        }
        }
        
        // Read m
        while (true) {
	        System.out.print("Enter m: ");
	        
	        try {
	        		m = Integer.parseInt(scanner.nextLine());
	        		if (m < 0) {
	        			System.out.println("m must be positive");
	        		}
	        } catch (NumberFormatException e) {
	        		System.out.println("m must be an int number");
	        }
	        
	        if (m >= 0) {
	        		break;
	        }
        }
        
        scanner.close();
        
        System.out.println("n = " + n);
        System.out.println("m = " + m);
        
        Expression exp = new Expression(C, n, m);
        System.out.println(String.format("S = %.5g%n", exp.calcExpression()));
    }
}
