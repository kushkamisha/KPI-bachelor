/**
 * Separator in sentence
 */
class Separator {
    private char separator;

    Separator(char newSeparator) {
        separator = newSeparator;
    }

    // Returns separator
    char getSeparator() {
        return separator;
    }
}
