/**
 * Simple letter
 */
class Letter {
    private char myLetter;

    Letter(char newLetter) {
        myLetter = newLetter;
    }

    // Returns single letter
    char getLetter() {
        return myLetter;
    }
}
